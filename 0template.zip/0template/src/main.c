/*
	main.c: Template test program
	author: Andre Cavalcante
	date: may, 2022
	license: CC BY-SA
*/

#include <stdio.h>

int main(int argc, char **argv) {
	//code here
	
	return 0;
}
